/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jp_assignment;
import java.io.*;
/**
 *
 * @author Lenovo
 */
public class JP_Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException {
        Staff_Login_Form SLF = new Staff_Login_Form();
        SLF.setVisible(true);
        
        //Creating and writing staff details into Staffs.txt file
        String[] username = {"Alexander", "Roberto", "Jennifer"};
        int[] password = {123456,234567,345678};
        try{
            FileWriter fw = new FileWriter("Staffs.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            for(int i = 0; i < username.length; i++ ){
                bw.write(username[i] + "\t" + password[i] + "\n");
            }
            bw.close();
            fw.close();
            
//          Creating and writing hotel rooms into Hotel_Rooms.txt file
            FileWriter fw1 = new FileWriter("Hotel_Rooms.txt");
            BufferedWriter bw1 = new BufferedWriter(fw1);
            for(int i = 1; i < 11; i++){
                bw1.write("roomJG"+i+"\t"+"Jungle View" + "\n");
            }
            for(int i = 1; i < 11; i++){
                bw1.write("roomSEA"+i+"\t"+"Sea View" + "\n");
            }
            bw1.close();
            fw1.close();
        }
        catch (Exception e){
            System.out.println("Something went wrong.");
        }              
    }
    
}
